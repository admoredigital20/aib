import { BOOTCAMP_LIST_FAIL, BOOTCAMP_LIST_REQUEST, BOOTCAMP_LIST_SUCCESS, CONTACTUS_FAIL, CONTACTUS_REQUEST, CONTACTUS_SUCCESS, HELP_LIST_FAIL, HELP_LIST_REQUEST, HELP_LIST_SUCCESS, SLIDER_EMAIL_FAIL, SLIDER_EMAIL_REQUEST, SLIDER_EMAIL_SUCCESS } from "../constants/generalConstant";

export const bootcampListReducer = (state = { loading: true }, action) => {
    switch (action.type) {
        case BOOTCAMP_LIST_REQUEST:
            return { loading: true };
        case BOOTCAMP_LIST_SUCCESS:
            return { loading: false, bootcamps: action.payload }
        case BOOTCAMP_LIST_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}

export const helpReducer = (state = { loading: true }, action) => {
    switch (action.type) {
        case HELP_LIST_REQUEST:
            return { loading: true }
        case HELP_LIST_SUCCESS:
            return { loading: false, helpQuery: action.payload }
        case HELP_LIST_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}

export const ConatactReducer = (state = { loading: true }, action) => {
    switch (action.type) {
        case CONTACTUS_REQUEST:
            return { loading: true }
        case CONTACTUS_SUCCESS:
            return { loading: false, contactQuery: action.payload ,success:true}
        case CONTACTUS_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state
    }
}

export const sliderEmailReducer=(state = { loading: true }, action)=>{
    switch(action.type){
        case SLIDER_EMAIL_REQUEST:
            return { loading: true }
        case SLIDER_EMAIL_SUCCESS:
            return { loading: false, contactQuery: action.payload ,success:true}
        case SLIDER_EMAIL_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state  
    }
}