const FullCoursess =[
    {
        id:1,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"All"


    },
    {
        id:2,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Free"

    },
    {
    id:3,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Paid"

    },
    {
        id:4,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"All"

    },
    {
        id:5,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Free"

    },
    {
        id:6,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Paid"

    },
    {
        id:7,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"All"

    },
    {
        id:8,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Free"

    },
    {
        id:9,
        image:"../assets/img/course1.jpg",
        name:"Information Visualization ",
        profile:"../assets/img/Rectangle-WS.png",
        category:"Paid"

    },

    
]

export default FullCoursess